# Roblox-FFlag-Modifier

FastFlags allow users to remotely modify and adjust the inner workings of client rendering and the physics engine. This was a tool I made which provides easier access for users to leverage this powerful functionality to modify vulnerable FFlags for semi-functional cheats or simply for developers to test specific client features. By modifying FastFlags, users can gain considerable advantages in gameplay without the use of any external exploits or executors.

(Bloxstrap is also supported because it contains a separate directory for roblox folders but it's kinda buggy for some reason)

FastFlags can be configured in the settings.py file. The Python interpreter is needed for code to run, Python can be downloaded from the link below:

https://www.python.org/downloads/
